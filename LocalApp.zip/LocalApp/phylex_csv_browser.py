# -*- coding: utf-8 -*-
"""
PHYLEX TREE BROWSER  -  CSV edition
=====================================
No database required. Loads phylex_final.csv directly into memory.

Usage:
    pip install flask
    python phylex_csv_browser.py
    python phylex_csv_browser.py --csv /path/to/phylex_final.csv --port 8080

Then open: http://localhost:5000
"""

import argparse
import csv
import io
import os
import secrets
from collections import defaultdict
from flask import Flask, jsonify, request, Response, stream_with_context, make_response

app = Flask(__name__)

# -- Config -------------------------------------------------------------------
DEFAULT_CSV = os.path.join(os.path.dirname(__file__), "phylex_final.csv")

# -- In-memory state ----------------------------------------------------------
_csv_path       = DEFAULT_CSV
state           = {}   # node_id -> {"name", "parent_id", "description"}
name_to_id      = {}   # name.lower() -> node_id
parent_children = defaultdict(list)   # parent_id -> [child_id, ...]
homo_path_ids   = set()               # node_ids on the Life -> Homo sapiens path

# ?? Load from CSV ?????????????????????????????????????????????????????????????

def _rebuild_homo_path():
    """Recompute the Life -> Homo sapiens ancestor set."""
    global homo_path_ids
    homo_path_ids = set()
    all_ids = set(state.keys())
    hs_id   = (name_to_id.get("homo sapiens sapiens")
               or name_to_id.get("homo sapiens"))
    if hs_id:
        cur, seen = hs_id, set()
        while cur and cur not in seen:
            homo_path_ids.add(cur)
            seen.add(cur)
            pid = state.get(cur, {}).get("parent_id")
            cur = pid if pid and pid in all_ids else None


def _csv_backup(node_id, new_parent_id):
    """Save full CSV snapshot named phylex_{node_id}_movedto_{new_parent_id}.csv."""
    csv_dir  = os.path.dirname(os.path.abspath(_csv_path))
    filename = f"phylex_{node_id}_movedto_{new_parent_id}.csv"
    out_path = os.path.join(csv_dir, filename)
    id2n     = {nid: d.get("name", "") for nid, d in state.items()}
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["node_id", "node_name", "parent_id", "parent_name", "description"])
        for nid, d in state.items():
            pid   = d.get("parent_id") or ""
            pname = id2n.get(pid, "")
            w.writerow([nid, d.get("name", ""), pid, pname, d.get("description", "")])
    print(f"Backup saved: {out_path}", flush=True)


def load_csv(path):
    global state, name_to_id, parent_children, homo_path_ids, _csv_path
    _csv_path = path
    print(f"Loading {path} ...", flush=True)
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV not found: {path}")

    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            nid  = (row.get("node_id")    or "").strip()
            name = (row.get("node_name")  or "").strip()
            pid  = (row.get("parent_id")  or "").strip() or None
            desc = (row.get("description") or "").strip()
            if not nid or not name:
                continue
            state[nid] = {"name": name, "parent_id": pid, "description": desc}

    all_ids = set(state.keys())
    print(f"  {len(state):,} clades loaded", flush=True)

    # Build indexes
    for nid, d in state.items():
        name_to_id[d["name"].lower()] = nid
        pid = d["parent_id"]
        if pid and pid in all_ids:
            parent_children[pid].append(nid)

    # Build path to Homo sapiens
    _rebuild_homo_path()
    print(f"  Path to Homo sapiens: {len(homo_path_ids)} nodes", flush=True)
    size_mb = os.path.getsize(path) / 1024 / 1024
    print(f"  File size: {size_mb:.2f} MB", flush=True)

# ?? API helpers ???????????????????????????????????????????????????????????????

def node_dict(nid):
    d   = state.get(nid, {})
    pid = d.get("parent_id") or ""
    return {
        "id":          nid,
        "name":        d.get("name", ""),
        "description": d.get("description", ""),
        "parent_id":   pid,
        "parent_name": state.get(pid, {}).get("name", ""),
        "child_count": len(parent_children.get(nid, [])),
        "on_path":     nid in homo_path_ids,
    }


def _generate_node_id():
    while True:
        nid = secrets.token_hex(12)
        if nid not in state:
            return nid

# ?? Routes ????????????????????????????????????????????????????????????????????

@app.route("/")
def index():
    return Response(HTML, mimetype="text/html")

@app.route("/api/root")
def api_root():
    all_ids = set(state.keys())
    life_id = name_to_id.get("life")
    if not life_id:
        for nid, d in state.items():
            pid = d.get("parent_id")
            if not pid or pid not in all_ids:
                life_id = nid
                break
    if not life_id:
        return jsonify({"error": "root not found"}), 404
    return jsonify(node_dict(life_id))

@app.route("/api/node/<node_id>")
def api_node(node_id):
    if node_id not in state:
        return jsonify({"error": "not found"}), 404
    return jsonify(node_dict(node_id))

@app.route("/api/children/<node_id>")
def api_children(node_id):
    kids = []
    for nid in parent_children.get(node_id, []):
        d = state.get(nid, {})
        kids.append({
            "id":          nid,
            "name":        d.get("name", ""),
            "child_count": len(parent_children.get(nid, [])),
            "on_path":     nid in homo_path_ids,
        })
    kids.sort(key=lambda x: x["name"].lower())
    return jsonify(kids)

@app.route("/api/breadcrumb/<node_id>")
def api_breadcrumb(node_id):
    crumbs, cur, seen = [], node_id, set()
    all_ids = set(state.keys())
    while cur and cur not in seen:
        d = state.get(cur)
        if not d:
            break
        seen.add(cur)
        crumbs.append({
            "id":      cur,
            "name":    d.get("name", ""),
            "on_path": cur in homo_path_ids,
        })
        pid = d.get("parent_id")
        cur = pid if pid and pid in all_ids else None
    crumbs.reverse()
    return jsonify(crumbs)

@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip().lower()
    if len(q) < 2:
        return jsonify([])
    results = []
    for nid, d in state.items():
        if q in d.get("name", "").lower():
            results.append({
                "id":          nid,
                "name":        d.get("name", ""),
                "child_count": len(parent_children.get(nid, [])),
                "on_path":     nid in homo_path_ids,
            })
            if len(results) >= 50:
                break
    results.sort(key=lambda x: (x["name"].lower().index(q), x["name"].lower()))
    return jsonify(results)

@app.route("/api/stats")
def api_stats():
    leaves    = sum(1 for nid in state if not parent_children.get(nid))
    with_desc = sum(1 for d in state.values() if d.get("description"))
    return jsonify({
        "total_clades":     len(state),
        "leaf_nodes":       leaves,
        "internal_nodes":   len(state) - leaves,
        "with_description": with_desc,
        "path_to_homo_len": len(homo_path_ids),
    })


@app.route("/api/move", methods=["POST"])
def api_move():
    data          = request.get_json() or {}
    node_id       = (data.get("node_id")       or "").strip()
    new_parent_id = (data.get("new_parent_id") or "").strip()
    if not node_id or not new_parent_id:
        return jsonify({"error": "node_id and new_parent_id are required"}), 400
    if node_id not in state:
        return jsonify({"error": f"Node '{node_id}' not found"}), 404
    if new_parent_id not in state:
        return jsonify({"error": f"Parent '{new_parent_id}' not found"}), 404
    if node_id == new_parent_id:
        return jsonify({"error": "Cannot move a node to itself"}), 400
    node            = state[node_id]
    new_parent      = state[new_parent_id]
    old_parent_id   = node.get("parent_id") or ""
    node_name       = node["name"]
    new_parent_name = new_parent["name"]
    # Incremental CSV backup before changing anything
    _csv_backup(node_id, new_parent_id)
    # Update in-memory state
    if old_parent_id and old_parent_id in parent_children:
        try: parent_children[old_parent_id].remove(node_id)
        except ValueError: pass
    state[node_id]["parent_id"] = new_parent_id
    parent_children[new_parent_id].append(node_id)
    _rebuild_homo_path()
    return jsonify({
        "node_id":         node_id,
        "node_name":       node_name,
        "old_parent_id":   old_parent_id,
        "new_parent_id":   new_parent_id,
        "new_parent_name": new_parent_name,
    })


@app.route("/api/add-child", methods=["POST"])
def api_add_child():
    data        = request.get_json() or {}
    parent_id   = (data.get("parent_id") or "").strip()
    child_name  = (data.get("name") or "").strip()
    description = (data.get("description") or "").strip()
    if not parent_id or not child_name:
        return jsonify({"error": "parent_id and name are required"}), 400
    if parent_id not in state:
        return jsonify({"error": f"Parent '{parent_id}' not found"}), 404
    new_id = _generate_node_id()
    state[new_id] = {
        "name": child_name,
        "parent_id": parent_id,
        "description": description,
    }
    name_to_id[child_name.lower()] = new_id
    parent_children[parent_id].append(new_id)
    _rebuild_homo_path()
    return jsonify({
        "id": new_id,
        "name": child_name,
        "parent_id": parent_id,
        "parent_name": state[parent_id]["name"],
    })


@app.route("/api/description/<node_id>", methods=["PUT"])
def api_description(node_id):
    if node_id not in state:
        return jsonify({"error": "not found"}), 404
    data = request.get_json() or {}
    state[node_id]["description"] = (data.get("description") or "").strip()
    return jsonify(node_dict(node_id))

@app.route("/api/rename/<node_id>", methods=["POST"])
def api_rename(node_id):
    """Rename a node"""
    if node_id not in state:
        return jsonify({"error": "not found"}), 404

    data = request.get_json() or {}
    new_name = (data.get("name") or "").strip()

    if not new_name:
        return jsonify({"error": "name is required"}), 400

    old_name = (state[node_id].get("name") or "").strip()

    # Update in-memory state
    state[node_id]["name"] = new_name

    # Update name index
    if old_name:
        name_to_id.pop(old_name.lower(), None)
    name_to_id[new_name.lower()] = node_id

    return jsonify({
        "id": node_id,
        "old_name": old_name,
        "new_name": new_name
    })

@app.route("/api/delete/<node_id>", methods=["POST"])
def api_delete(node_id):
    if node_id not in state:
        return jsonify({"error": "not found"}), 404
    if parent_children.get(node_id):
        return jsonify({"error": "Cannot delete a node that has children"}), 400
    parent_id = state[node_id].get("parent_id") or ""
    if not parent_id:
        return jsonify({"error": "Cannot delete root node"}), 400
    name = state[node_id].get("name", "")
    if parent_id in parent_children:
        try:
            parent_children[parent_id].remove(node_id)
        except ValueError:
            pass
    name_to_id.pop(name.lower(), None)
    parent_children.pop(node_id, None)
    state.pop(node_id, None)
    _rebuild_homo_path()
    return jsonify({"deleted_id": node_id, "deleted_name": name, "parent_id": parent_id})


@app.route("/api/export")
def api_export():
    all_ids = set(state.keys())
    id2n    = {nid: d.get("name", "") for nid, d in state.items()}
    buf = io.StringIO()
    w   = csv.writer(buf)
    w.writerow(["node_id", "node_name", "parent_id", "parent_name", "description"])
    for nid, d in state.items():
        pid   = d.get("parent_id") or ""
        pname = id2n.get(pid, "") if pid in all_ids else ""
        w.writerow([nid, d.get("name", ""), pid, pname, d.get("description", "")])
    output = buf.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=phylex_export.csv"}
    )

@app.after_request
def add_no_cache_headers(resp):
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp

# ?? Inline HTML ???????????????????????????????????????????????????????????????

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Phylex Tree Browser</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background:#1a1a2e; min-height:100vh; display:flex; flex-direction:column;
}
.header {
  background:linear-gradient(135deg,#0f3460 0%,#16213e 100%);
  color:white; padding:16px 24px; display:flex; align-items:center;
  gap:20px; border-bottom:2px solid #0f3460; flex-shrink:0;
}
.header h1 { font-size:1.4em; font-weight:700; flex-shrink:0; }
.search-wrap { position:relative; flex:1; max-width:500px; }
.search-wrap input {
  width:100%; padding:9px 16px; border-radius:6px; border:none; font-size:14px;
  background:rgba(255,255,255,0.12); color:white; outline:none;
}
.search-wrap input::placeholder { color:rgba(255,255,255,0.5); }
.search-wrap input:focus { background:rgba(255,255,255,0.2); }
.search-dropdown {
  display:none; position:absolute; top:calc(100% + 6px); left:0; right:0;
  background:#16213e; border:1px solid #0f3460; border-radius:6px;
  max-height:360px; overflow-y:auto; z-index:999;
  box-shadow:0 8px 32px rgba(0,0,0,0.5);
}
.search-dropdown.open { display:block; }
.sd-item {
  padding:10px 16px; cursor:pointer;
  border-bottom:1px solid rgba(255,255,255,0.06); color:#e0e0e0; font-size:14px;
}
.sd-item:hover { background:#0f3460; }
.sd-item .sd-meta { font-size:12px; color:#888; margin-top:2px; }
.sd-item.on-path { border-left:3px solid #4caf50; }
.stats-pill { margin-left:auto; font-size:12px; color:rgba(255,255,255,0.5); white-space:nowrap; }
.app { display:flex; flex:1; overflow:hidden; }
.sidebar {
  width:220px; flex-shrink:0; background:#16213e;
  border-right:1px solid #0f3460; overflow-y:auto; padding:12px 8px;
}
.sidebar-title {
  color:#888; font-size:11px; font-weight:600;
  letter-spacing:1px; text-transform:uppercase; padding:0 8px 10px;
}
.crumb {
  padding:8px 12px; border-radius:5px; cursor:pointer; font-size:13px;
  color:#b0b8cc; margin-bottom:2px; white-space:nowrap;
  overflow:hidden; text-overflow:ellipsis; border-left:3px solid transparent;
}
.crumb:hover { background:#0f3460; color:white; }
.crumb.active { background:#0f3460; color:white; font-weight:600; }
.crumb.on-path { border-left-color:#4caf50; }
.main { flex:1; overflow-y:auto; padding:24px; background:#1a1a2e; }
.node-header {
  background:#16213e; border-radius:10px; padding:20px 24px;
  margin-bottom:20px; border-left:4px solid #667eea;
}
.node-header.on-path { border-left-color:#4caf50; background:#0d2b1a; }
.node-title { font-size:1.8em; font-weight:700; color:#e0e0e0; margin-bottom:6px; }
.node-title.on-path { color:#4caf50; }
.badges { display:flex; gap:8px; flex-wrap:wrap; margin-top:6px; }
.badge { display:inline-block; padding:3px 10px; border-radius:12px; font-size:12px; font-weight:600; }
.badge-path { background:#1b5e20; color:#81c784; }
.badge-id   { background:#1a237e; color:#90caf9; font-family:monospace; }
.node-desc  { margin-top:12px; color:#9e9e9e; font-size:14px; line-height:1.6; }
.children-title {
  color:#888; font-size:12px; font-weight:600;
  letter-spacing:1px; text-transform:uppercase; margin-bottom:12px;
}
.children-grid {
  display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:10px;
}
.child-card {
  background:#16213e; border:1px solid #0f3460; border-radius:8px;
  padding:14px; cursor:pointer; transition:all 0.15s; border-left:3px solid transparent;
}
.child-card:hover { background:#0f3460; transform:translateY(-1px); }
.child-card.on-path { border-left-color:#4caf50; background:#0d2b1a; }
.child-card.on-path:hover { background:#143d25; }
.child-name { font-size:14px; font-weight:600; color:#e0e0e0; margin-bottom:4px; }
.child-card.on-path .child-name { color:#4caf50; }
.child-meta { font-size:12px; color:#666; }
.leaf-msg { color:#555; text-align:center; padding:40px; font-size:14px; }
.error-msg {
  background:#3e1a1a; color:#e57373; border-radius:8px;
  padding:16px 20px; margin-bottom:20px; font-size:14px;
}
/* Toolbar */
.toolbar {
  background:#16213e; border-bottom:1px solid #0f3460;
  padding:10px 24px; display:flex; align-items:center;
  gap:10px; flex-wrap:wrap; flex-shrink:0;
}
.tb-input {
  padding:7px 11px; border-radius:5px; border:1px solid #0f3460;
  background:#1a1a2e; color:#e0e0e0; font-size:13px; width:205px; outline:none;
}
.tb-input:focus { border-color:#667eea; }
.tb-btn {
  padding:7px 14px; border-radius:5px; border:none;
  cursor:pointer; font-size:13px; font-weight:600;
}
.btn-move         { background:#0f3460; color:#90caf9; }
.btn-move:hover   { background:#1565c0; }
.btn-export       { background:#1b5e20; color:#81c784; }
.btn-export:hover { background:#2e7d32; }
.btn-add          { background:#5d4037; color:#ffccbc; }
.btn-add:hover    { background:#6d4c41; }
.btn-edit         { background:#37474f; color:#b0bec5; }
.btn-edit:hover   { background:#455a64; }
.btn-delete       { background:#5d1a1a; color:#ef9a9a; }
.btn-delete:hover { background:#7f1d1d; }
.tb-sep   { color:#667eea; font-size:16px; padding:0 2px; }
.tb-right { margin-left:auto; display:flex; gap:8px; }
.tb-status { font-size:13px; padding:4px 10px; border-radius:4px; display:none; }
.tb-ok  { display:inline-block !important; background:#1b5e20; color:#81c784; }
.tb-err { display:inline-block !important; background:#3e1a1a; color:#e57373; }
.node-id { font-family:monospace; font-size:12px; color:#667eea; margin:3px 0 10px; }
.node-actions { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; align-items:center; }
.node-actions .btn-delete { margin-left:auto; }
/* Responsive adjustments */
@media (max-width: 768px) {
  .header, .footer {
    padding: 12px 16px;
  }
  .node-header, .toolbar {
    flex-direction: column;
    gap: 8px;
  }
  .tb-input {
    width: 100%;
  }
  .children-grid {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  }
}
</style>
</head>
<body>
<div class="header">
  <h1>&#127807; Phylex</h1>
  <div class="search-wrap">
    <input type="text" id="searchInput" placeholder="Search species or taxon...">
    <div class="search-dropdown" id="searchDropdown"></div>
  </div>
  <div class="stats-pill" id="statsPill"></div>
</div>
<div class="toolbar">
  <input class="tb-input" id="moveFrom" placeholder="Node ID to move" spellcheck="false">
  <span class="tb-sep">&#8594;</span>
  <input class="tb-input" id="moveTo" placeholder="New parent ID" spellcheck="false">
  <button class="tb-btn btn-move" onclick="moveNode()">Move</button>
  <input class="tb-input" id="childParent" placeholder="Parent ID for new child" spellcheck="false">
  <input class="tb-input" id="childName" placeholder="New child name" spellcheck="false">
  <button class="tb-btn btn-add" onclick="addChild()">Add Child</button>
  <span id="tbStatus" class="tb-status"></span>
  <div class="tb-right">
    <button class="tb-btn btn-export" onclick="exportCSV()">&#8595;&nbsp;Export CSV</button>
  </div>
</div>
<div class="app">
  <div class="sidebar" id="sidebar"><div class="sidebar-title">Path</div></div>
  <div class="main"    id="main"></div>
</div>
<script>
let currentId = null;
let currentNode = null;
let searchTimer = null;

async function boot() {
  showMainLoading();
  try {
    const [root, stats] = await Promise.all([get('/api/root'), get('/api/stats')]);
    document.getElementById('statsPill').textContent =
      `${stats.total_clades.toLocaleString()} clades  \u00b7  ${stats.with_description.toLocaleString()} described`;
    await navigate(root.id);
  } catch(e) { showError('Could not load: ' + e.message); }
}

async function navigate(nodeId) {
  currentId = nodeId;
  showMainLoading();
  try {
    const [node, children, crumbs] = await Promise.all([
      get('/api/node/'       + nodeId),
      get('/api/children/'   + nodeId),
      get('/api/breadcrumb/' + nodeId),
    ]);
    renderSidebar(crumbs);
    renderMain(node, children);
  } catch(e) { showError('Navigation error: ' + e.message); }
}

function renderSidebar(crumbs) {
  const el = document.getElementById('sidebar');
  let html = '<div class="sidebar-title">Path</div>';
  // Reverse the crumbs so Life is at bottom and current node at top
  const reversedCrumbs = [...crumbs].reverse();
  reversedCrumbs.forEach((c, i) => {
    const active = i === 0 ? 'active' : '';
    const op     = c.on_path ? 'on-path' : '';
    html += `<div class="crumb ${active} ${op}" onclick="navigate('${c.id}')">${esc(c.name)}</div>`;
  });
  el.innerHTML = html;
}

function renderMain(node, children) {
  currentNode = node;
  const el  = document.getElementById('main');
  const op  = node.on_path;
  let badges = op ? '<span class="badge badge-path">&#10003;&nbsp;Path to Homo sapiens</span>' : '';
  const desc = node.description ? `<div class="node-desc">${esc(node.description)}</div>` : '<div class="node-desc" style="color:#666">No description</div>';

  let html = `
    <div class="${op ? 'node-header on-path' : 'node-header'}">
      <div class="${op ? 'node-title on-path' : 'node-title'}">${esc(node.name)}</div>
      ${badges ? `<div class="badges">${badges}</div>` : ''}
      <div class="node-id">${esc(node.id)}</div>
      ${desc}
      <div class="node-actions">
        <button class="tb-btn btn-edit" onclick="renameNode()">Rename Node</button>
        <button class="tb-btn btn-edit" onclick="editDescription()">Edit Description</button>
        <button class="tb-btn btn-delete" onclick="deleteCurrentNode()">Delete Node</button>
      </div>
    </div>`;

  if (children.length > 0) {
    html += `<div class="children-title">${children.length} children</div>
             <div class="children-grid">`;
    children.forEach(c => {
      const cls = c.on_path ? 'child-card on-path' : 'child-card';
      html += `<div class="${cls}" onclick="navigate('${c.id}')">
                 <div class="child-name">${esc(c.name)}</div>
                 <div class="child-meta">${c.child_count} children</div>
               </div>`;
    });
    html += '</div>';
  } else {
    html += '<div class="leaf-msg">Leaf node &mdash; no children</div>';
  }
  el.innerHTML = html;
}

document.getElementById('searchInput').addEventListener('input', e => {
  clearTimeout(searchTimer);
  const q = e.target.value.trim();
  if (q.length < 2) { closeSearch(); return; }
  searchTimer = setTimeout(() => doSearch(q), 250);
});
document.addEventListener('click', e => {
  if (!e.target.closest('.search-wrap')) closeSearch();
});

async function doSearch(q) {
  try {
    const results = await get('/api/search?q=' + encodeURIComponent(q));
    const dd = document.getElementById('searchDropdown');
    dd.innerHTML = results.length
      ? results.map(r => `
          <div class="sd-item ${r.on_path ? 'on-path' : ''}" onclick="selectResult('${r.id}')">
            ${esc(r.name)}<div class="sd-meta">${r.child_count} children</div>
          </div>`).join('')
      : '<div class="sd-item" style="color:#666">No results</div>';
    dd.classList.add('open');
  } catch(e) {}
}
function selectResult(id) {
  document.getElementById('searchInput').value = '';
  closeSearch(); navigate(id);
}
function closeSearch() {
  document.getElementById('searchDropdown').classList.remove('open');
}
async function get(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(r.status + ' ' + r.statusText);
  return r.json();
}
function showMainLoading() {
  document.getElementById('main').innerHTML =
    '<div style="color:#555;padding:40px;text-align:center;font-size:14px">Loading...</div>';
}
function showError(msg) {
  document.getElementById('main').innerHTML =
    `<div class="error-msg">Error: ${esc(msg)}</div>`;
}
function esc(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

async function moveNode() {
  const fromId = document.getElementById('moveFrom').value.trim();
  const toId   = document.getElementById('moveTo').value.trim();
  if (!fromId || !toId) { tbStatus('Enter both node IDs', false); return; }
  try {
    const r = await fetch('/api/move', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({node_id: fromId, new_parent_id: toId})
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    tbStatus('Moved "' + d.node_name + '" -> "' + d.new_parent_name + '"', true);
    document.getElementById('moveFrom').value = '';
    document.getElementById('moveTo').value   = '';
    if (currentId === fromId || currentId === d.old_parent_id || currentId === toId)
      navigate(currentId);
  } catch(e) { tbStatus('Error: ' + e.message, false); }
}

async function addChild() {
  const parentId = document.getElementById('childParent').value.trim();
  const name     = document.getElementById('childName').value.trim();
  if (!parentId || !name) { tbStatus('Enter parent ID and child name', false); return; }
  try {
    const r = await fetch('/api/add-child', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({parent_id: parentId, name})
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    tbStatus('Added child "' + d.name + '" (' + d.id + ')', true);
    document.getElementById('childParent').value = '';
    document.getElementById('childName').value   = '';
    if (currentId === parentId) navigate(currentId);
  } catch(e) { tbStatus('Error: ' + e.message, false); }
}

async function renameNode() {
  if (!currentNode) return;
  const newName = prompt('Rename node:', currentNode.name);
  if (newName === null || newName.trim() === '') return;
  if (newName.trim() === currentNode.name) return;
  try {
    const r = await fetch('/api/rename/' + currentNode.id, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name: newName.trim()})
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    tbStatus('Renamed from "' + d.old_name + '" to "' + d.new_name + '"', true);
    navigate(currentNode.id);
  } catch(e) { tbStatus('Error: ' + e.message, false); }
}

async function editDescription() {
  if (!currentNode) return;
  const description = prompt('Edit description for ' + currentNode.name, currentNode.description || '');
  if (description === null) return;
  try {
    const r = await fetch('/api/description/' + currentNode.id, {
      method:'PUT', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({description})
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    tbStatus('Description updated', true);
    navigate(currentNode.id);
  } catch(e) { tbStatus('Error: ' + e.message, false); }
}

async function deleteCurrentNode() {
  if (!currentNode) return;
  if (!confirm('Delete node "' + currentNode.name + '"? Only leaf nodes can be deleted.')) return;
  try {
    const r = await fetch('/api/delete/' + currentNode.id, {method:'POST'});
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || r.statusText);
    tbStatus('Deleted "' + d.deleted_name + '"', true);
    navigate(d.parent_id || (await get('/api/root')).id);
  } catch(e) { tbStatus('Error: ' + e.message, false); }
}

function tbStatus(msg, ok) {
  const el = document.getElementById('tbStatus');
  el.textContent = msg;
  el.className   = 'tb-status ' + (ok ? 'tb-ok' : 'tb-err');
  clearTimeout(tbStatus._t);
  tbStatus._t = setTimeout(() => { el.className = 'tb-status'; }, 5000);
}

function exportCSV() { window.location = '/api/export'; }

boot();
</script>
</body>
</html>
"""

# ?? Main ??????????????????????????????????????????????????????????????????????

def main():
    parser = argparse.ArgumentParser(description="Phylex Tree Browser (CSV)")
    parser.add_argument("--csv",  default=DEFAULT_CSV, help="Path to phylex_final.csv")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    print("\n" + "="*60)
    print("PHYLEX TREE BROWSER  [CSV]")
    print("="*60)

    load_csv(args.csv)

    print(f"\nOpen: http://{args.host}:{args.port}")
    print("="*60 + "\n")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
